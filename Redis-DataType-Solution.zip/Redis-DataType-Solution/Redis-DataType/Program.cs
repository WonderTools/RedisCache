using ServiceStack.Redis;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Redis_DataType
{
    class Program
    {
        static void Main(string[] args)
        {
            using (IRedisClient client = new RedisClient())
            {
                Program p = new Program();

                // 1. List Operation
                //p.ListOperation(client);

                // 2. Hash Operation
                //p.HashOperation(client);

                // 3. Sorted Set Operation
                p.SortedSetOperation(client);

                // Clear Cache
                client.FlushAll();
                Console.ReadLine();
            }

        }

        public void ListOperation(IRedisClient client)
        {
            List<string> num = new List<string> { "9", "8", "6", "4", "2" };
            client.AddRangeToList("num", num);
            List<string> result = client.GetRangeFromList("num", 0, -1);
            foreach (var data in result)
            {
                Console.WriteLine("value: {0}", data);

            }

            // Remove all element in list except 6 & 4
            client.TrimList("num", 2, 3);
            List<string> result1 = client.GetRangeFromList("num", 0, -1);
            foreach (var data in result1)
            {
                Console.WriteLine("value: {0}", data);

            }
            // Add 1 at begining of list and 10 at end of list
            client.PrependItemToList("num", "Mohit");
            client.AddItemToList("num", "Manju");
            List<string> result2 = client.GetRangeFromList("num", 0, -1);
            foreach (var data in result2)
            {
                Console.WriteLine("value: {0}", data);

            }
        }

        public void HashOperation(IRedisClient client)
        {
            var hashKey = "hashKey";
            Dictionary<string, string> ht = new Dictionary<string, string>();
            ht.Add("id", "007");
            ht.Add("Name", "Souvik");
            ht.Add("Team", "Mantra");
            client.SetRangeInHash(hashKey, ht);
            Dictionary<string, string> result = client.GetAllEntriesFromHash(hashKey);
            foreach (var data in result)
            {
                Console.WriteLine("key:{0}, value: {1}", data.Key, data.Value);

            }

            // Set Entry In Hash If surName field doesnot Exists
            client.SetEntryInHashIfNotExists(hashKey, "surName", "Mukherjee");
            Dictionary<string, string> result1 = client.GetAllEntriesFromHash(hashKey);
            foreach (var data in result1)
            {
                Console.WriteLine("key:{0}, value: {1}", data.Key, data.Value);

            }

            // Check if hash has Name key, if exist change name to Alam
            if(client.HashContainsEntry(hashKey,"Name"))
            {
                client.SetEntryInHash(hashKey, "Name", "Alam");
                Dictionary<string, string> result2 = client.GetAllEntriesFromHash(hashKey);
                foreach (var data in result2)
                {
                    Console.WriteLine("key:{0}, value: {1}", data.Key, data.Value);

                }
            }
        }

        public void SortedSetOperation(IRedisClient client)
        {
            var setkey = "myset1";
            client.AddItemToSortedSet(setkey, "Abhay", 30);
            client.AddItemToSortedSet(setkey, "Geethu", 28);
            client.AddItemToSortedSet(setkey, "Shailesh", 31);
            List<string> result = client.GetAllItemsFromSortedSet(setkey);
            foreach (var data in result)
            {
                Console.WriteLine("value: {0}", data);

            }

            // Get Range from sorted set by lowest score between 20 to 30
            List<string> result1 = client.GetRangeFromSortedSetByLowestScore(setkey, 20, 30);
            foreach (var data in result1)
            {
                Console.WriteLine("value: {0}", data);

            }
            // Create two different Set and Find Union and store in third set
            var setkey2 = "myset2";
            client.AddItemToSortedSet(setkey, "Abhay", 30);
            client.AddItemToSortedSet(setkey, "Geethu", 28);
            client.AddItemToSortedSet(setkey, "Mohit", 31);
            string[] st = new string[2] { setkey, setkey2 };
            client.StoreUnionFromSortedSets("myset3", st);
            List<string> result2 = client.GetAllItemsFromSortedSet(setkey);
            foreach (var data in result2)
            {
                Console.WriteLine("value: {0}", data);

            }
        }
    }
}
