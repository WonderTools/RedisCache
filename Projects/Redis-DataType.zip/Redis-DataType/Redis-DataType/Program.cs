using ServiceStack.Redis;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Redis_DataType
{
    class Program
    {
        static void Main(string[] args)
        {
            using (IRedisClient client = new RedisClient())
            {
                Program p = new Program();

                // 1. List Operation
                //p.ListOperation(client);

                // 2. Hash Operation
                //p.HashOperation(client);

                // 3. Sorted Set Operation
                p.SortedSetOperation(client);

                // Clear Cache
                client.FlushAll();
                Console.ReadLine();
            }

        }

        public void ListOperation(IRedisClient client)
        {
            List<string> num = new List<string> { "9", "8", "6", "4", "2" };
            client.AddRangeToList("num", num);
            List<string> result = client.GetRangeFromList("num", 0, -1);
            foreach (var data in result)
            {
                Console.WriteLine("value: {0}", data);

            }

            // Remove all element in list except 6 & 4
            

            // Add 1 at begining of list and 10 at end of list
            
        }

        public void HashOperation(IRedisClient client)
        {
            var hashKey = "hashKey";
            Dictionary<string, string> ht = new Dictionary<string, string>();
            ht.Add("id", "007");
            ht.Add("Name", "Souvik");
            ht.Add("Team", "Mantra");
            client.SetRangeInHash(hashKey, ht);
            Dictionary<string, string> result = client.GetAllEntriesFromHash(hashKey);
            foreach (var data in result)
            {
                Console.WriteLine("key:{0}, value: {1}", data.Key, data.Value);

            }

            // Set Entry In Hash If surName field doesnot Exists
            

            // Check if hash has Name key, if exist change name to Alam
            
        }

        public void SortedSetOperation(IRedisClient client)
        {
            var setkey = "myset1";
            client.AddItemToSortedSet(setkey, "Abhay", 30);
            client.AddItemToSortedSet(setkey, "Geethu", 28);
            client.AddItemToSortedSet(setkey, "Shailesh", 31);
            List<string> result = client.GetAllItemsFromSortedSet(setkey);
            foreach (var data in result)
            {
                Console.WriteLine("value: {0}", data);

            }

            // Get Range from sorted set by lowest score between 20 to 30
            

            // Create two different Set and Find Union and store in third set
           

        }
    }
}
