using ServiceStack.Redis;
using System;

namespace Redis_Connection
{
    class Program
    {
        static void Main(string[] args)
        {
            //password@localhost:6379
            var manager = new RedisManagerPool("localhost:6379");
            using (var client = manager.GetClient())
            {
                client.Set("name", "Anmol");
                Console.WriteLine("name={0}", client.Get<string>("name"));
                Console.ReadLine();
            }
        }
    }
}
